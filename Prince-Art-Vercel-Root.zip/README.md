# My complete website — Windows, GitHub and Vercel

This is the complete existing Prince Art Packages website with its latest navy, teal and gold colors. All 26 pages and all 57 website files are preserved byte-for-byte. It uses static HTML, CSS and JavaScript, not React or Next.js. No third-party packages, installation step or dependency lockfile is required. `package.json` is included for convenient commands.

## Files to upload

Open this folder and select ALL its contents, including:

```
index.html
design.css
brand-colors.css
interactions.js
assets/
about/
blog/
capabilities/
case-studies/
contact/
industries/
innovation/
privacy/
products/
quality/
terms/
scripts/
.gitignore
.vercelignore
package.json
page-inventory.json
serve.mjs
vercel.json
README.md
DEPLOY-VERCEL.md
```

`assets/` includes the existing images, logos, favicon and local fonts. All nested product pages and blog articles are included. There were no local video assets in the source project. Do not upload just `index.html`, and do not upload the ZIP itself in place of the extracted source.

## 1. Download and extract on Windows

Download `my-complete-website.zip`. In File Explorer, right-click it, choose **Extract All**, select a destination and click **Extract**. Open the inner `my-complete-website` folder containing `index.html` and `package.json`.

## 2. Preview locally (optional)

Install Node.js 18 or newer if necessary. Open a terminal in this folder and run:

```sh
node scripts/build.mjs
node serve.mjs
```

Then open http://127.0.0.1:4173/. Press Ctrl+C to stop. If npm is available, `npm start` runs both commands. No `npm install` is necessary. Do not double-click index.html: root-relative paths need the local server.

The build validates the site and copies the public files unchanged to a generated `dist/` folder. It does not compile, redesign, minify or change the site. `dist/` is excluded from Git and from this ZIP because Vercel generates it.

## 3. Create a GitHub repository

Visit https://github.com/new and sign in. Enter a name such as `prince-art-packages`, choose your visibility, and leave README, .gitignore and license initialization unchecked because this export already includes the needed files. Click **Create repository**.

## 4. Upload the project manually

On the empty repository page, click **uploading an existing file** (or **Add file > Upload files** for an initialized repository). In File Explorer, open the inner project folder, press Ctrl+A, and drag its contents into the GitHub upload area. Include every folder and the dotfiles `.gitignore` and `.vercelignore`. Wait for uploads to finish, enter a commit message, and choose **Commit changes**.

Confirm that `index.html`, `package.json` and `vercel.json` appear directly at the repository root, next to `assets/` and all page folders. The project has fewer than 100 files and each is smaller than 25 MiB. If a browser omits dotfiles, add them individually using **Add file > Upload files** or **Create new file**.

## 5. Deploy using Vercel

Sign in at https://vercel.com, choose **Add New > Project**, connect GitHub if needed, select your new repository and click **Import**. Use a new Vercel project; do not change the existing business website's project or domain.

Use these settings (already specified in `vercel.json`):

| Setting | Value |
|---|---|
| Root Directory | Repository root (`.`) |
| Framework Preset | Other |
| Install Command | Empty / skipped |
| Build Command | `node scripts/build.mjs` |
| Output Directory | `dist` |
| Environment variables | None required |

Click **Deploy**. Open the generated Vercel link and check the homepage, products, a product detail page, journal and contact page. If you uploaded the outer folder instead of its contents, choose `my-complete-website` as Vercel's Root Directory.

Do not add a catch-all rewrite to index.html: this is a real multi-page site. Keep the included trailing-slash setting. Connecting your existing custom domain is a separate action; these export files do not change your current domain or live site.

## Existing integrations

Quote forms preserve their existing behavior: prepare an email, download an enquiry, or open the original secure enquiry form. They do not silently send email. Google Maps and the original secure enquiry form require internet. All core fonts, images, styles and JavaScript are included locally.

Social-sharing metadata still references the earlier configured Site origin. Before a public launch, update those metadata URLs to your approved new domain if you want sharing previews to use it; visible website files have deliberately been preserved unchanged for this export.

No repository history, node_modules, private environment files, credentials, hosting account identities or temporary build outputs are included. Nothing has been uploaded automatically.

References:
- https://docs.github.com/en/repositories/working-with-files/managing-files/adding-a-file-to-a-repository
- https://vercel.com/docs/git
- https://vercel.com/docs/project-configuration/vercel-json
