# Vercel deployment

Follow the complete Windows, GitHub and Vercel instructions in [README.md](README.md).

Framework: Other. Root: repository root. Install: skipped. Build: `node scripts/build.mjs`. Output: `dist`. No environment variables required.

The build copies the existing root-level HTML, CSS, JavaScript and assets without changing their content.
