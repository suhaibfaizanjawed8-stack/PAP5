import './verify-site.mjs';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
if (process.exitCode) process.exit(process.exitCode);
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const output = path.join(root, 'dist');
const inventory = JSON.parse(fs.readFileSync(path.join(root, 'page-inventory.json'), 'utf8'));
const pages = inventory.map(({ route }) => path.join(route.replace(/^\//, ''), 'index.html'));
fs.mkdirSync(output, { recursive: true });
for (const file of [...pages, 'design.css', 'brand-colors.css', 'interactions.js']) {
  const dest = path.join(output, file);
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  fs.copyFileSync(path.join(root, file), dest);
}
fs.cpSync(path.join(root, 'assets'), path.join(output, 'assets'), { recursive: true });
console.log('Static website copied unchanged to dist.');
