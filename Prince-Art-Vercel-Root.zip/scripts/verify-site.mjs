import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import vm from 'node:vm';

const project = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const root = project;
const files = dir => fs.readdirSync(dir, { withFileTypes: true }).filter(item => !['dist', 'node_modules', '.git', '.vercel'].includes(item.name)).flatMap(item => item.isDirectory() ? files(path.join(dir, item.name)) : [path.join(dir, item.name)]);
const inventory = JSON.parse(fs.readFileSync(path.join(project, 'page-inventory.json'), 'utf8'));
const allFiles = files(root);
const htmlFiles = allFiles.filter(file => file.endsWith('.html'));
const errors = [];
const source = new Map(htmlFiles.map(file => [file, fs.readFileSync(file, 'utf8')]));
const ids = new Map([...source].map(([file, html]) => [file, new Set([...html.matchAll(/\bid=["']([^"']+)["']/g)].map(match => match[1]))]));

function checkReference(file, reference) {
  const raw = reference.replaceAll('&amp;', '&').trim();
  if (!raw || /^(?:[a-z][a-z\d+.-]*:|\/\/)/i.test(raw)) return;
  const url = new URL(raw, 'https://local.invalid/' + path.relative(root, file).split(path.sep).join('/'));
  let target = path.resolve(root, '.' + decodeURIComponent(url.pathname));
  if (target !== root && !target.startsWith(root + path.sep)) { errors.push(`Path outside website: ${reference}`); return; }
  if (fs.existsSync(target) && fs.statSync(target).isDirectory()) target = path.join(target, 'index.html');
  if (!fs.existsSync(target) || !fs.statSync(target).isFile()) { errors.push(`${path.relative(root, file)}: missing ${reference}`); return; }
  if (url.hash && ids.has(target) && !ids.get(target).has(decodeURIComponent(url.hash.slice(1)))) errors.push(`${path.relative(root, file)}: missing anchor ${reference}`);
}

for (const [file, html] of source) {
  if ([...html.matchAll(/<h1\b/gi)].length !== 1) errors.push(`${file}: expected one primary heading`);
  for (const match of html.matchAll(/\b(?:href|src)=["']([^"']+)["']/g)) checkReference(file, match[1]);
  for (const match of html.matchAll(/\bsrcset=["']([^"']+)["']/g)) for (const image of match[1].split(',')) checkReference(file, image.trim().split(/\s+/)[0]);
}
for (const file of allFiles.filter(file => file.endsWith('.css'))) {
  for (const match of fs.readFileSync(file, 'utf8').matchAll(/url\(\s*["']?([^"')]+)["']?\s*\)/g)) checkReference(file, match[1]);
}
for (const { route } of inventory) {
  if (!fs.existsSync(path.join(root, route, 'index.html'))) errors.push(`Missing page route ${route}`);
}
for (const file of allFiles.filter(file => file.endsWith('.js'))) {
  try { new vm.Script(fs.readFileSync(file, 'utf8'), { filename: file }); }
  catch (error) { errors.push(`JavaScript syntax check failed: ${file}: ${error.message}`); }
}
if (htmlFiles.length !== inventory.length) errors.push('Page count differs from the content inventory');
if (errors.length) { console.error(errors.join('\n')); process.exitCode = 1; }
else console.log(`PASS: ${htmlFiles.length} pages; local links, anchors, images, fonts, CSS references and JavaScript syntax verified. No website files modified.`);
