Prince Art Packages - Hostinger static website

Upload this ZIP into your domain's public_html directory using Hostinger File Manager. Extract its contents directly into public_html. index.html must be public_html/index.html, not inside another folder. Back up any existing site before replacing files. No build, npm installation, database or extra software is required. This package targets the domain root.

Includes 26 HTML pages, separate design.css, brand-colors.css, interactions.js, and all local images, logos and fonts. The existing website content and public files have been copied unchanged.

FORM: Preparing an enquiry opens the visitor's email application. The visitor must send the email themselves. Download enquiry saves a text file; it does not send anything. No server-side message-sending service is included. The original secure enquiry form and Google Maps are external services requiring internet.

Validation: all 26 HTML pages passed local href/src/srcset, anchor and CSS asset reference checks, plus JavaScript syntax validation. Files were compared by SHA256 against the existing source. No claim is made that external services or email delivery were tested. Social-sharing metadata still contains the previous Site domain and should be updated when your final domain is known.
