PRINCE ART PACKAGES — VERCEL READY STATIC WEBSITE

This ZIP is complete. Keep the folder structure exactly as supplied.

IMPORTANT FILES
- index.html                 Homepage
- design.css                 Main website styles
- brand-colors.css           Brand colors
- interactions.js            Menu, slider and UI interactions
- vercel.json                Vercel deployment settings
- assets/images/             All local website images
- assets/fonts/              Local fonts/icons
- about/, products/, etc.    Separate website pages

DEPLOY THROUGH GITHUB + VERCEL
1. Extract this ZIP.
2. Upload ALL files and folders to the ROOT of your GitHub repository.
3. Do not upload only index.html. The folders about, products, industries, assets, etc. are required.
4. In Vercel, import that GitHub repository.
5. Framework Preset: Other.
6. Root Directory: repository root (leave blank unless these files are inside another folder).
7. Build Command: leave blank / none.
8. Output Directory: leave blank for this static site.
9. Deploy.

After deployment test:
/
/about/
/products/
/capabilities/
/innovation/
/quality/
/industries/
/blog/
/contact/

If your current Vercel project still shows the old broken version, replace the repository contents with this complete package and redeploy from the latest Git commit.
