import { cpSync, existsSync, mkdirSync, readdirSync, rmSync } from 'node:fs';
import { join } from 'node:path';

const root = process.cwd();
const dist = join(root, 'dist');
rmSync(dist, { recursive: true, force: true });
mkdirSync(dist, { recursive: true });

const skip = new Set(['dist', '.git', 'node_modules', 'package.json', 'package-lock.json', 'build.mjs', 'vercel.json', 'README-DEPLOY.txt']);
for (const entry of readdirSync(root, { withFileTypes: true })) {
  if (skip.has(entry.name)) continue;
  cpSync(join(root, entry.name), join(dist, entry.name), { recursive: true });
}

const required = [
  'index.html',
  'innovation.html',
  'industries.html',
  'products.html',
  'about.html',
  'contact.html',
  'design.css',
  'interactions.js',
  'assets/images/prod_cartons.webp',
  'assets/images/prod_leaflets.webp',
  'assets/images/prod_labels.webp',
  'assets/images/prod_tamper_labels.webp',
  'innovation/index.html',
  'industries/index.html',
  'products/index.html'
];
for (const file of required) {
  if (!existsSync(join(dist, file))) {
    throw new Error(`Required deployment file missing: ${file}`);
  }
}
console.log(`Verified static deployment output: ${dist}`);
