# Prince Art Packages - final GitHub and Vercel project

Extract the ZIP and upload ALL extracted contents to the TOP LEVEL of your GitHub repository. index.html, vercel.json, package.json and scripts/ must appear immediately on the repository main page. Do not upload the ZIP itself or a containing folder.

## Exact Vercel settings for this ZIP

Root Directory: leave blank (repository root).
Framework Preset: Other.
Build Command: node scripts/build.mjs
Output Directory: dist
Install Command: enable Override and leave the command empty (skip installation).
No environment variables or dependency installation are required.

The included vercel.json already sets the framework, build command, output directory, install command and trailing slashes. Root Directory is a Vercel dashboard setting; it must be the repository root for this archive layout.

Vercel dashboard: open your project > Settings > Build and Deployment. Clear any previous nested Root Directory. Set the values above and Save. Then Deployments > latest deployment > three-dot menu > Redeploy. Select the environment you intend to update. If GitHub files changed, deploy the latest commit rather than an older deployment's source.

## Website files

index.html is the homepage. Other routes use their own folders containing index.html. Keep all folders together, including assets/ (images and fonts), all page folders, scripts/, design.css, brand-colors.css, interactions.js, package.json, page-inventory.json, .gitignore and .vercelignore.

The build validates 26 pages and copies their files without altering content into dist/. dist/index.html is the deployed homepage. dist/ is intentionally excluded from the ZIP and Git because Vercel generates it. Do not add a catch-all rewrite: this is a multi-page website.

## Local use

With Node.js installed: node scripts/build.mjs, then node serve.mjs. Open http://127.0.0.1:4173/. No npm install needed.

## Limitations

Enquiry forms open the visitor's email application or download an enquiry text file. They do not automatically send messages. Google Maps and the original secure enquiry form require external internet access. Existing social-sharing metadata uses the previously configured Site origin; update it when your approved final domain is known. Website design, text, images and links are preserved.

Local build and HTTP tests do not confirm a live Vercel deployment. A live deployment URL must be tested separately.
