PRINCE ART PACKAGES — FIXED VERCEL PACKAGE

WHAT WAS FIXED
- Navigation now points to real .html files (example: innovation.html) so Vercel cannot lose the page route.
- vercel.json includes compatibility rewrites for old URLs such as /innovation and /products/printed-cartons.
- All packaging/industry images are stored locally under assets/images/.
- CSS, JavaScript, fonts, logo, favicon and images are included in this package.
- Asset paths are relative, so the pages also show images when index.html is opened locally after extraction.

DEPLOY
1. Extract this ZIP.
2. In GitHub, upload ALL files/folders from inside the extracted folder. index.html and vercel.json must be at repository root.
3. Vercel Framework Preset: Other.
4. Build Command: leave blank.
5. Output Directory: leave blank.
6. Redeploy.

IMPORTANT
Do not upload only index.html. Upload assets/, all .html files, CSS, JS and vercel.json together.
